#!/bin/bash

gcc -o bancoColaMensajes bancoColaMensajes.c
./bancoColaMensajes
