#!/bin/bash

gcc -o rAulas rAulas.c
./rAulas
