#!/bin/bash

gcc -o abcd_pipes abcd_pipes.c
./abcd_pipes
