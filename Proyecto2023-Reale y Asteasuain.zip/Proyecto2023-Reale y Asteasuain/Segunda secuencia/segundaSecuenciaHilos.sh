#!/bin/bash

gcc -o ABCD-V2 ABCD-V2.c -lpthread
./ABCD-V2
