#!/bin/bash

gcc -o bancoColaMensajes bancoColaMensajes.c
./bancoColaMjes
