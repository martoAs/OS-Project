#!/bin/bash

gcc -o sincronizacion1b sincronizacion1b.c
./sincronizacion1b
