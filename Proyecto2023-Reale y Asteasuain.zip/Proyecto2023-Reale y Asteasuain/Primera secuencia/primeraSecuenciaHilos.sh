#!/bin/bash

gcc -o sincronizacion1a sincronizacion1a.c
./sincronizacion1a
