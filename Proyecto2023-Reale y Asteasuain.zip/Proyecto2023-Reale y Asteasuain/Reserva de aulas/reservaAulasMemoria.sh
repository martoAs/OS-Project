#!/bin/bash

gcc -o rAulasMemoria rAulasMemoria.c
./rAulasMemoria