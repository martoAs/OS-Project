#!/bin/bash

gcc -o banco banco.c -lpthread
./banco
