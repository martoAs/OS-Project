#!/bin/bash

gcc -o rAulasMemoria rAulasMemoria.c -lpthread
./rAulasMemoria