#!/bin/bash

gcc -o sincronizacion1a sincronizacion1a.c -lpthread
./sincronizacion1a
